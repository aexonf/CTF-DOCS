<?php

phpinfo();

?>
